﻿using System;
using System.Text;
using System.Net;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Threading;
using Emgu.CV;
using System.IO;

namespace faceShow
{
    public partial class Form1 : Form
    {
        Capture capture;
        public Form1()
        {
            InitializeComponent();
            timer1.Interval = 1000; // 设置时间间隔为1000ms，默认为100ms
            timer1.Start();  // 启动计时器, 默认不启动

        }

        /// <summary>
        /// 登录操作。。。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
          

            try
            {
                this.toolStripTextBox1.Text = DB.GetAppSettingConfig("RTSP");
                string RTSPStreamText = toolStripTextBox1.Text.Trim();
                capture = new Capture(RTSPStreamText);
                capture.ImageGrabbed += Capture_ImageGrabbed;
                capture.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            //  Thread myThread = new Thread(new ThreadStart(udpRs));
            //myThread.Start();
        }

        public void openSerialPort()
        {
            try
            {
                if (!this.serialPort1.IsOpen)
                {
                    this.serialPort1.DataBits = 8;
                    this.serialPort1.BaudRate = 9600;
                    this.serialPort1.PortName = DB.GetAppSettingConfig("COMNUM");
                    this.serialPort1.StopBits = System.IO.Ports.StopBits.One;
                    this.serialPort1.Parity = System.IO.Ports.Parity.None;
                    this.serialPort1.Encoding = System.Text.Encoding.UTF8;
                    serialPort1.Open();
                }

            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }
       
        /// <summary>
        /// 捕获图像的事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Capture_ImageGrabbed(object sender, EventArgs e)
        {
            //新建一个Mat
            Mat frame = new Mat();
            //将得到的图像检索到frame中
            capture.Retrieve(frame, 0);
            //将图像赋值到IBShow的Image中完成显示
            imageBox1.Image = frame;
        }

        /// <summary>
        /// 计时器定时读取文件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                StreamReader sr1 = new StreamReader("d:\\name.txt", Encoding.UTF8);
                this.label2.Text = sr1.ReadLine();
                StreamReader sr2 = new StreamReader("d:\\identity.txt", Encoding.UTF8);
                this.label4.Text = sr2.ReadLine();
                FileInfo fi = new FileInfo("d:\\name.txt");
                this.label6.Text = fi.LastWriteTime.ToString();

                StreamReader sr3 = new StreamReader("d:\\shot.txt", Encoding.UTF8);
                string userPhoto = sr3.ReadLine();
                sr1.Close();
                sr2.Close();
                sr3.Close();

                byte[] arr2 = Convert.FromBase64String(userPhoto);
                using (MemoryStream ms2 = new MemoryStream(arr2))
                {
                    System.Drawing.Bitmap bmp2 = new System.Drawing.Bitmap(ms2);
                    this.pictureBox1.Image = bmp2;
                }
                // this.pictureBox1.ImageLocation = "D:\\picture.jpg";
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }

        }

        string indata = string.Empty;
        /// <summary>
        /// 串口接收到数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            try
            {
                indata = serialPort1.ReadExisting();
                this.BeginInvoke(new EventHandler(DisplayText));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        public void DisplayText(object sender, EventArgs e)
        {

            string s = WineData.wineDetect(100, 100);//100 分别是风扇 和 酒精值
            this.label8.Text = s;
        }

        /// <summary>
        /// 提交数据到数据库
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.label8.Text = DB.GetConnectionString("DBConnectionString");
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString());
            }
        }
    }
}

