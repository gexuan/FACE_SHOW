﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Configuration;
using System.Linq;
using System.Text;


namespace faceShow
{
    public class DB
    {
        public OleDbConnection GetCon()
        {
            string oledbconn = GetConnectionString("DBConnectionString");
            return new OleDbConnection(oledbconn);
        }

        /// <summary>
        /// 获取配置文件字符
        /// </summary>
        /// <param name="connectionName"></param>
        /// <returns></returns>
        public static string GetAppSettingConfig(string connectionName)
        {
            //指定config文件读取
            string file = System.Windows.Forms.Application.ExecutablePath;
            Configuration config = ConfigurationManager.OpenExeConfiguration(file);
            string name = config.AppSettings.Settings[connectionName].Value.ToString();
            return name;
            //string connectionString = config.ConnectionStrings.ConnectionStrings[connectionName].ConnectionString.ToString();
            //return connectionString;
        }
        public static string GetConnectionString(string connectionName)
        {
            //指定config文件读取
            string file = System.Windows.Forms.Application.ExecutablePath;
            Configuration config = ConfigurationManager.OpenExeConfiguration(file);
            string connectionString = config.ConnectionStrings.ConnectionStrings[connectionName].ConnectionString.ToString();
            return connectionString;
        }

        /// <summary>
        /// 执行sql语句
        /// </summary>
        /// <param name="cmdstr">sql语句</param>
        /// <returns>返回值为int类型，成功返回1，失败返回0</returns>

        public int sqlEx(string cmdstr)
        {
            OleDbConnection con = GetCon();
          //  con.Open();
            OleDbCommand cmd = new OleDbCommand(cmdstr, con);
            try
            {
                cmd.ExecuteNonQuery();
                return 1;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return 0;
            }
            finally
            {
                con.Dispose();
            }

        }

        /// <summary>
        /// 执行sql查询语句
        /// </summary>
        /// <param name="cmdstr">查询语句</param>
        /// <returns>datatable 数据表</returns>
        public DataTable reDt(string cmdstr)
        {
            OleDbConnection con = GetCon();
            OleDbDataAdapter da = new OleDbDataAdapter(cmdstr, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return (ds.Tables[0]);

        }

        /// <summary>
        /// sqldatareader 返回只读数据
        /// </summary>
        /// <param name="str">查询语句</param>
        /// <returns>SQLdatareader 对象 dr</returns>
        public OleDbDataReader reDR(string str)
        {
            OleDbConnection conn = GetCon();
            conn.Open();
            OleDbCommand com = new OleDbCommand(str, conn);
            OleDbDataReader dr = com.ExecuteReader(CommandBehavior.CloseConnection);
            return dr;
        }

    }
}