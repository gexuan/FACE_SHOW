﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace faceShow
{
    class WineData
    {
        public static string wineDetect(int fengshan, int jiujing)
        {

            string result = string.Empty;

            if (fengshan == 0)
            {

                return result = "未检测到吹气";
                
            }
            else
            {
                result = "酒精浓度为" + jiujing + "";
                if (jiujing > 100)
                {
                    return result + ",疑似班前饮酒";
                }
                else
                {
                    return result + "，正常";

                }
            }
        }
    }
}
